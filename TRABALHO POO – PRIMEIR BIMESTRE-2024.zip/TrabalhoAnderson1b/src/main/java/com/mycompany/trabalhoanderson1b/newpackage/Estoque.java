package com.mycompany.trabalhoanderson1b.newpackage;

public class Estoque {

    public int getQuantidadeLivros() {
        return quantidadeLivros;
    }

    public void setQuantidadeLivros(int quantidadeLivros) {
        this.quantidadeLivros = quantidadeLivros;
    }

    public int getAtualizacaoEstoque() {
        return atualizacaoEstoque;
    }

    public void setAtualizacaoEstoque(int atualizacaoEstoque) {
        this.atualizacaoEstoque = atualizacaoEstoque;
    }
    private int quantidadeLivros;
    private int atualizacaoEstoque;
}
