package com.mycompany.trabalhoanderson1b.newpackage;

public class Cliente {
    private String nomeCliente;
    private String sexoCliente;
    private int idadeCliente;
    private String documento;
    private Endereco endereco;

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }


    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getSexoCliente() {
        return sexoCliente;
    }

    public void setSexoCliente(String sexoCliente) {
        this.sexoCliente = sexoCliente;
    }

    public int getIdadeCliente() {
        return idadeCliente;
    }

    public void setIdadeCliente(int idadeCliente) {
        this.idadeCliente = idadeCliente;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nomeCliente=" + nomeCliente + ", sexoCliente=" + sexoCliente + ", idadeCliente=" + idadeCliente + ", documento=" + documento + ", endereco=" + endereco + '}';
    }
}
